﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Point3D
{
    class ProgramTests
    {
        static void Main(string[] args)
        {
            // Имам зверска температура, за това нямам тестове и домашното ще го добутам до шеста задача включително
        }
    }
}
